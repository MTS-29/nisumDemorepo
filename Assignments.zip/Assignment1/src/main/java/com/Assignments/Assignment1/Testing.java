package com.Assignments.Assignment1;

import java.util.Scanner;

public class Testing {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		com.Assignments.Assignment1.stack s1 = new com.Assignments.Assignment1.stack();
		String bracketsToCheck = sc.next();
		boolean status;
		status = s1.checkBalance(bracketsToCheck);
		System.out.println(status);
		sc.close();
	}
}
