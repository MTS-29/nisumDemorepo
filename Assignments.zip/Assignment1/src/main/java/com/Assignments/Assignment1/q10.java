package com.Assignments.Assignment1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//10)
//Given a class FileReverse. Implement the following things in this class.
//Define a method getReverseFile(File). This method should return a string that contains reverse
//of the content in a file.
//For example: inputFile.txt contains
//abc def ghi
//jkl MNoP 12d
//qrst uv wx yz
//Output:
//zy xw vu tsrq
//d21 PoNM lkj
//ihg fed cba

public class q10 {
	public static void main(String[] args) throws FileNotFoundException {
		File f1 = new File("D:\\Programs\\Assignment1\\src\\main\\java\\com\\Assignments\\Assignment1\\Textfile.txt");
		Scanner sc = new Scanner(f1);
		String ans = "";
		String rev = "";
		List<String> dataList = new ArrayList<>();
		while(sc.hasNextLine()) {
			String data = sc.nextLine();
			ans+=data+"\n";
		}
//		System.out.println(ans);
		
//		Converted String to mutable using stringbuilder and then reversed the string and again converted back to string.
		StringBuilder sb=new StringBuilder(ans);  
	    System.out.println(sb.reverse().toString());
	    
	}

}
