package com.Assignments.Assignment1;

import java.lang.reflect.Array;

public class q1 {
	public static void main(String[] args) {

//	1) Write a Java program to swap the first and last elements of an array
//	EXAMPLES OF INPUT/OUTPUT:
//	Input : {20, 30, 40, 50};
//	Output: 50, 30, 40, 20};
		int a[] = { 20, 30, 40, 50 }, temp;
		temp = a[0];
		a[0] = a[a.length - 1];
		a[a.length - 1] = temp;
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
	}
}
