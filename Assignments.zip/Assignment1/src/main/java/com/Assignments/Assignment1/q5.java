package com.Assignments.Assignment1;

import java.util.Scanner;

public class q5 {
	public static void main(String[] args) {
//		5) Fibonacci series without using recursive function
//		EX: 0,1,1,2,3,5,8,13
		
		int a =0,b = 1,n=5,temp;
//		Scanner sc = new Scanner(System.in);
		System.out.println(a+"\n"+b);
		for (int i = 0; i < n-2; i++) {
			System.out.println(b);
			temp = a; 
			a = b;
			b=temp+b;
			
		}
	}

}
