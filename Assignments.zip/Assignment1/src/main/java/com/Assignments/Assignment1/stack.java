package com.Assignments.Assignment1;

import java.util.Scanner;
import java.util.Stack;


public class stack{
	public boolean checkBalance(String bracketsToCheck){
		Stack<Character> s = new Stack<>();
		for(int i = 0; i < bracketsToCheck.length(); i++) {
			
			if (bracketsToCheck.charAt(i)=='(' || bracketsToCheck.charAt(i)=='{' || bracketsToCheck.charAt(i)=='[' ) {				
				s.push(bracketsToCheck.charAt(i));
			}
			else if (bracketsToCheck.charAt(i)==')' && s.peek().equals('(')) {
				s.pop();
			}
			else if(bracketsToCheck.charAt(i)=='}' && s.peek().equals('{')){
				s.pop();
			}
			else if(bracketsToCheck.charAt(i)==']' && s.peek().equals('[')) {
				s.pop();
			}
			
		}
		if (!s.empty()) {
			return false;
		}
		else {
			return true;
		}
	}
}

//8)
//In computer science, a stack or LIFO (last in, first out) is an abstract data type that serves as a
//collection of elements, with two principal operations: push, which adds an element to the
//collection, and pop, which removes the last element that was added.
//Examples of some correctly balanced strings are: "{}()", "[{()}]", "({()})"
//Examples of some unbalanced strings are: "{}(", "({)}", "[[", "}{" etc.
//You are given a class Stack and a class Testing.
//Define a method in class Stack with the following specifications :-
//Method Name : checkBalance
//Return Type : boolean
//Parameter : String
//
//Access Modifier : public
//Within checkBalance method, a String is passed as parameter and in which you have to write
//the
//code to check whether the string is balanced or not.
//If String is balanced then return true otherwise return false. Also, if string is blank or null, return
//false.
//NOTE:
//Use & edit Testing class to test your code in which we have populated different string values.


