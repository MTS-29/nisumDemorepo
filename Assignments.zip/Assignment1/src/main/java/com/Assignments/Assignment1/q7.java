package com.Assignments.Assignment1;
import java.util.*;

//7) Write code for decrypting given text
//Explanation:
//Plain Text string is "abcdefghijklmnopqrstuvwxyz";
//Cipher Text string is "zyxwvutsrqponmlkjihgfedcba";
//if the input is "zyx", that need to be changed to "abc".
//Input: zyx
//Output: abc
//index of "z" in cipher text is equal to index of "a" in plain text
//index of "y" is cipher text equal to index of "b" in plain text and so on.
//Cipher text character from the given string should be changed to plain text character with the
//same index.

public class q7 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String plainText = "abcdefghijklmnopqrstuvwxyz";
		String cipherText = "zyxwvutsrqponmlkjihgfedcba";
		int i=0;
		String toDecrypt = sc.next();
		for (int j = 0; j < toDecrypt.length(); j++) {
			int idx = cipherText.indexOf(toDecrypt.charAt(j));
			System.out.print(plainText.charAt(idx));
			idx++;
		}
	}
}
