package com.Assignments.Assignment1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class q6 {
	public static void main(String[] args) {
//		6) How to Sort HashMap by Value? write an example program
		Map<String,Integer> m = new HashMap<>();
		m.put("Sion",22);
		m.put("Harish",24);
		m.put("Nithin", 25);
		m.put("Taqui",40);
		
		List<Integer> l = new ArrayList<>();
		LinkedHashMap<String,Integer> sm = new LinkedHashMap<>(); 
		for(Map.Entry<String, Integer> entry: m.entrySet()) {
			l.add(entry.getValue());
		}
		Collections.sort(l);
		
		for(int i : l) {
			for (Map.Entry<String, Integer> entry : m.entrySet()) {
				if (entry.getValue().equals(i)) {
					sm.put(entry.getKey(), entry.getValue());
				}
			}
		}
		
		System.out.println(sm);
	}
}
