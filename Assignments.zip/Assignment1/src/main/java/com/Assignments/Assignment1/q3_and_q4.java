//	3) Avoid the duplicates, default ascending order list order and optionally provide sort by
//	name/age/sal/tax.
//	The employee object has first name last name, age, empId, sal and tax properties
//	List of employees — 100, May be duplicates.
package com.Assignments.Assignment1;

import java.util.*;

class Employee {
	private String name;
	private int age;
	private int sal;
	private int tax;

	public Employee(String n, int a, int s) {
		this.name = n;
		this.age = a;
		this.sal = s;
		if (sal>20000) {			
			this.tax = (s*20)/100;
		}
	}

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public int getSal() {
		return sal;
	}

	public int getTax() {
		return tax;
	}
}

public class q3_and_q4 {
	public static int compareName(String s1, String s2) {
		return s1.compareTo(s2);
	}

	public static int compareAge(int s1, int s2) {
		return s1 - s2;
	}

	public static int compareSal(int s1, int s2) {
		return s1 - s2;
	}

	public static int compareTax(int s1, int s2) {
		return s1 - s2;
	}

	public static void main(String[] args) {

		Employee e1 = new Employee("Sion", 22, 40000);
		Employee e3 = new Employee("Babulu", 30, 510000);
		Employee e2 = new Employee("Test1", 23, 410000);
		
		List<Employee> emp = new ArrayList<>();
		emp.add(e1);
		emp.add(e2);
		emp.add(e3);
		Scanner sc = new Scanner(System.in);
		System.out.println(
				"1. Sort wrt name" + "\n" + "2. Sort wrt age" + "\n" + "3. Sort wrt salary" + "\n" + "4. Sort wrt tax");
		final int whatToCompare = sc.nextInt();
//		Sort using name
		Collections.sort(emp, new Comparator<Employee>() {
			@Override
			public int compare(Employee p1, Employee p2) {
				switch (whatToCompare) {
				case 1:
					return compareName(p1.getName(), p2.getName());
				case 2:
					return compareAge(p1.getAge(), p2.getAge());
				case 3:
					return compareSal(p1.getSal(), p2.getSal());
				case 4:
					return compareTax(p1.getTax(), p2.getTax());
				default:
					return 0;
				}

			}

		});
		for (int i = 0; i < emp.size(); i++) {
			System.out.println(emp.get(i).getName() + " " + emp.get(i).getAge() + " " + emp.get(i).getSal() + " "
					+ emp.get(i).getTax());
		}

	}
}
