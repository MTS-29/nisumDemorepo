package com.Assignments.Assignment1;

public class q2 {
	public static void main(String[] args) {
//    	2) Write a program to count the number of triples (characters appearing three times in a row) in
//    a given string
//
//    EXAMPLES OF INPUT/OUTPUT:
//    Input : aaabbbccdddcefffgghiiijk
//    Output: 5
		String s = "aaabbbccdddcefffgghiiijk";
		int finalCount = 0;

		for (int i = 0; i < s.length()-2; i++) {
			char temp = s.charAt(i);
			if (temp==s.charAt(i+1) && temp==s.charAt(i+2)) {
				finalCount+=1;
			}
		}
		System.out.println(finalCount);

	}
}
