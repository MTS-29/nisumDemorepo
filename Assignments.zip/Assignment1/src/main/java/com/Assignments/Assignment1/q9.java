package com.Assignments.Assignment1;

public class q9 {
	public static void main(String args[]) {
		String computerMove = null;
		switch ((int) (3 * Math.random())) {
		case 0:
			computerMove = "Rock";
			break;
		case 1:
			computerMove = "Scissors";
			break;
		case 2:
			computerMove = "Paper";
			break;
		}
		System.out.println("Computer's move is " + computerMove);
	}
}
// Output will be different each time because we are giving random numbers each time we are running the program