package com.Assignments.Assignment1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

//11)
//Given a class DataFile.
//Implement the following things in this class.
//Define a method readStudents(RandomAccessFile raf) that read the data from a file line by line.
//Where the file contains the data as follows.
//inputFile.txt
//-------------
//111:Hari:56:58:68
//222:Rajanikanth:65:56:57
//333:Girija:69:45:89
//Above row represents StudentId,Name,sub1,sub2,sub3 respectively.
//Return null if the inputFile is empty.
//After reading every line from the file, this method should create a list of student objects with the
//details along with total marks for each student.
class DataFile{
	
	DataFile(){
		
	}
	public void readStudents() {
		
	}
}


public class q11 {
	
	public static void main(String[] args) throws FileNotFoundException {
//		File f1 = new File("D:\\Programs\\Assignment1\\src\\main\\java\\com\\Assignments\\Assignment1\\inputFile.txt");
//		Scanner sc = new Scanner(f1);
//		String data="";
		List<Integer> id = new ArrayList<Integer>();
		List<String> name = new ArrayList<>();
		List<Integer> s1 =  new ArrayList<Integer>();
		List<Integer> s2 =  new ArrayList<Integer>();
		List<Integer> s3 =  new ArrayList<Integer>();
//		Reading the file lie by line
		try (BufferedReader in = new BufferedReader(new FileReader("D:\\Programs\\Assignment1\\src\\main\\java\\com\\Assignments\\Assignment1\\inputFile.txt"))){
			String data;
			while ((data= in.readLine())!=null) {
				String[] info = data.split(":");
				id.add(Integer.parseInt(info[0]));
				name.add(info[1]);
				s1.add(Integer.parseInt(info[2]));
				s2.add(Integer.parseInt(info[3]));
				s3.add(Integer.parseInt(info[4]));
				for (int i = 0; i < name.size(); i++) {
					System.out.println(id.get(i));
					System.out.println(name.get(i));
					System.out.println(s1.get(i));
					System.out.println(s2.get(i));
					System.out.println(s3.get(i));
				}
				
			}
			
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
		List<DataFile> df = new ArrayList<>();
		
		
		
		
		
		
	}
}
